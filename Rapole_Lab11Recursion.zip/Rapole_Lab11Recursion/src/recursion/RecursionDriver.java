/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package recursion;

import java.util.ArrayList;

/**
 *
 * @author Shirisha Reddy Rapole
 */
public class RecursionDriver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Recursion recursion = new Recursion();

        System.out.println("Sum of odd: " + recursion.sumOfOdd(5));

        ArrayList<Student> student = new ArrayList<Student>();
        Student student1 = new Student("Adam");
        Student student2 = new Student("Bob");
        Student student3 = new Student("Charlie");
        Student student4 = new Student("David");
        Student student5 = new Student("Elfie");
        student.add(student1);
        student.add(student2);
        student.add(student3);
        student.add(student4);
        student.add(student5);

        ArrayList<Student> studentArrayList = new ArrayList<>(student);
        
        for(ArrayList<Student> stud : recursion.organizeSeats(student)){
            System.out.println(stud);     
        }
       
        System.out.println("\nPossibilities of such restricted arrangement:\n");
        for (ArrayList<Student> stud : recursion.organizeSeats(studentArrayList, student2, student3, studentArrayList.size())) {
            System.out.println(stud);
        }
        System.out.println("\nEvaluation of given expressions:\n");
        
        System.out.println("(1+2) = "+recursion.evaluateExpression("(1+2)"));
        System.out.println("(1+3)/(2%5) = "+recursion.evaluateExpression("(1+3)/(2%5)"));
        System.out.println("((2+4)*((3*2)-(2/4)+(9%4))) = "+recursion.evaluateExpression("((2+4)*((3*2)-(2/4)+(9%4)))"));
        System.out.println("(2+4)/((7/3)+(2*4))+(8*4)/((9-2)-(-8*9)) = "+recursion.evaluateExpression("(2+4)/((7/3)+(2*4))+(8*4)/((9-2)-(-8*9))"));
        System.out.println("(3-1)/((3%3)/(-3*4)+(-7/6)%(-9/5)) = "+recursion.evaluateExpression("(3-1)/((3%3)/(-3*4)+(-7/6)%(-9/5))"));
        System.out.println("");
    }
    
}
