/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package recursion;

import java.util.ArrayList;

/**
 *
 * @author Shirisha Reddy Rapole
 */
public class Recursion {

    public int sumOfOdd(int n) {

        if (n == 0) {
            return 0;
        } else {
            if (n % 2 != 0) {
                return n + sumOfOdd(n - 1);
            } else {
                return sumOfOdd(n - 1);
            }
        }
    }

    public ArrayList<ArrayList<Student>> organizeSeats(ArrayList<Student> studentList) {
        if (studentList.isEmpty()) {
            ArrayList<ArrayList<Student>> res_arrayList = new ArrayList<>();
            res_arrayList.add(new ArrayList<>());
            return res_arrayList;
        }
        ArrayList<ArrayList<Student>> final_value = new ArrayList<>();
        Student frst_ele = studentList.remove(0);
        ArrayList<ArrayList<Student>> diff_vals = organizeSeats(studentList);
        for (ArrayList<Student> vals : diff_vals) {
            for (int i = 0; i <= vals.size(); i++) {
                ArrayList<Student> var = new ArrayList<>(vals);
                var.add(i, frst_ele);
                final_value.add(var);
            }
        }

        return final_value;

    }

    public ArrayList<ArrayList<Student>> organizeSeats(ArrayList<Student> studentList,
            Student s1, Student s2, int size) {

        if (studentList.isEmpty()) {
            ArrayList<ArrayList<Student>> res = new ArrayList<>();
            res.add(new ArrayList<>());
            return res;
        }
        ArrayList<ArrayList<Student>> ret_value = new ArrayList<>();
        Student firstElement = studentList.remove(0);

        ArrayList<ArrayList<Student>> diff_values = organizeSeats(studentList, s1, s2, size);

        for (ArrayList<Student> vals : diff_values) {
            for (int i = 0; i <= vals.size(); i++) {
                ArrayList<Student> var = new ArrayList<>(vals);
                var.add(i, firstElement);

                ret_value.add(var);
            }
        }

        if (ret_value.get(0).size() == size) {
            int j = 0;
            while (j < ret_value.size()) {

                for (int i = 0; i < ret_value.get(j).size() - 1; i++) {
                    if ((ret_value.get(j).get(i).equals(s1) && ret_value.get(j).get(i + 1).equals(s2))
                            || (ret_value.get(j).get(i).equals(s2) && ret_value.get(j).get(i + 1).equals(s1))) {
                        ret_value.remove(j);
                        j = 0;
                        break;
                    }
                }
                j++;
            }
        }
        return ret_value;
    }

    public double evaluateExpression(String str) {

        if (!str.contains("+") && !str.contains("*") && !str.contains("/") && !str.contains("%")) {
            if ((!str.contains("-") || str.indexOf("-") == str.lastIndexOf("-")) && (str.indexOf("-") == -1 || str.indexOf("-") == 0)) {
                return Double.parseDouble(str);
            }
        }

        while (str.indexOf(")") != -1) {
            int frst_closingBraces = str.indexOf(")");
            if (frst_closingBraces != -1) {
                int lst_openingBraces = str.substring(0, frst_closingBraces).lastIndexOf("(");

                if (lst_openingBraces != -1) {

                    String leftBraces = str.substring(0, lst_openingBraces);
                    String expr = str.substring(lst_openingBraces + 1, frst_closingBraces);
                    String rightBraces = str.substring(frst_closingBraces + 1, str.length());

                    if (leftBraces.length() == 0 && rightBraces.length() == 0) {
                        return evaluateExpression(expr);
                    } else {
                        str = leftBraces + evaluateExpression(expr) + rightBraces;
                    }
                }
            }
        }
        str = str.replaceAll("--", "+");
        int i;
        for (i = str.length() - 1; i >= 0; i--) {
            if (str.charAt(i) == '+') {
                break;
            } else if (str.charAt(i) == '-' && i > 0) {
                if (!(str.charAt(i - 1) == '+' || str.charAt(i - 1) == '*'
                        || str.charAt(i - 1) == '/' || str.charAt(i - 1) == '%'
                        || str.charAt(i - 1) == '(')) {
                    break;
                }
            }
        }
        if (i < 0) {
            for (i = str.length() - 1; i >= 0; i--) {
                if (str.charAt(i) == '*' || str.charAt(i) == '/' || str.charAt(i) == '%') {
                    break;
                }
            }
        }

        if (i < 0) {
            return evaluateExpression(str);
        }

        String string1 = str.substring(0, i);
        String string2 = str.substring(i + 1, str.length());

        if (string1.length() == 0 && string2.length() > 0) {
            return evaluateExpression(string2);
        } else if (string2.length() == 0 && string1.length() > 0) {
            return evaluateExpression(string1);
        } else if (string1.length() == 0 && string2.length() == 0) {
            return 0;
        }
        double expression_result = 0;

        switch (str.charAt(i)) {
            case '+':
                expression_result = evaluateExpression(string1) + evaluateExpression(string2);
                break;
            case '-':
                expression_result = evaluateExpression(string1) - evaluateExpression(string2);
                break;
            case '%':
                expression_result = evaluateExpression(string1) % evaluateExpression(string2);
                break;
            case '*':
                expression_result = evaluateExpression(string1) * evaluateExpression(string2);
                break;
            case '/':
                double right = evaluateExpression(string2);
                if (right == 0) {
                    System.out.println("Invalid divisor");
                    System.exit(1);
                } else {
                    expression_result = evaluateExpression(string1) / right;
                }
                break;
        }
        return expression_result;

    }

}
